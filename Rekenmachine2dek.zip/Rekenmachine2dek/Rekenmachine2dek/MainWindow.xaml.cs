﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Rekenmachine2dek
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
         private double firstDoubleNumber = 0;
        private double secondDoubleNumber = 0;
        private string myOperator = null;
        private bool isNewNumber = true;
        private bool EenComma = false;

        public MainWindow()
        {
            InitializeComponent();
            resultTextBox.Text = "0";
        }

        private void Number_Click(object sender, RoutedEventArgs e)
        {
            if (isNewNumber)
            {
                resultTextBox.Text = "";
                isNewNumber = false;
            }
            Button button = (Button)sender;

            resultTextBox.Text += (sender as Button).Content.ToString();
            UpdateOperationText();
        }

        private void Operation_Click(object sender, RoutedEventArgs e)
        {
            myOperator = (sender as Button).Content.ToString();

            try
            {
                firstDoubleNumber = double.Parse(resultTextBox.Text);
                operationTextBlock.Text = $"{firstDoubleNumber} {myOperator}";
            }
            catch
            {
                MessageBox.Show("Please insert a valid number!");
                resultTextBox.Text = "";
                operationTextBlock.Text = "0";
            }

            isNewNumber = true;
            EenComma = false;
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            resultTextBox.Text = "";
            myOperator = null;
            isNewNumber = true;
            resultTextBox.Text = "0";
            operationTextBlock.Text = "";
            EenComma = false;
        }

        private void UpdateOperationText()
        {
            if (myOperator != null)
            {
                operationTextBlock.Text = $"{firstDoubleNumber} {myOperator} {resultTextBox.Text}";
            }
        }

        private void Equal_Click(object sender, RoutedEventArgs e)
        {
            if (myOperator == null)
                return;

            secondDoubleNumber = double.Parse(resultTextBox.Text);
            double result = 0;

            switch (myOperator)
            {
                case "+":
                    result = firstDoubleNumber + secondDoubleNumber;
                    break;
                case "-":
                    result = firstDoubleNumber - secondDoubleNumber;
                    break;
                case "X":
                    result = firstDoubleNumber * secondDoubleNumber;
                    break;
                case "/":
                    if (secondDoubleNumber != 0)
                    {
                        result = firstDoubleNumber / secondDoubleNumber;
                    }
                    else
                    {
                        MessageBox.Show("Kan niet!");
                        Clear_Click(null, null);
                        return;
                    }
                    break;
            }

            result = Math.Round(result, 2);
            resultTextBox.Text = result.ToString();
            isNewNumber = true;
            EenComma = true;
            //operationTextBlock.Text = "";
            operationTextBlock.Text = $"{firstDoubleNumber} {myOperator} {secondDoubleNumber} = {result}";

        }

        private void Dot_Click(object sender, RoutedEventArgs e)
        {
            if (!EenComma)
            {
                resultTextBox.Text = resultTextBox.Text + ".";
                EenComma = true;
            }
        }
    }
}